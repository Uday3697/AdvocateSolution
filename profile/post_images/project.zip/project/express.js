var express = require("express");
var app = express();
app.server = require('http').createServer(app);

app.use(express.static(__dirname + '/public'));

app.get("/",  function(req, res) {
	res.sendFile(__dirname + "/phone/"+"index.html");
});

var server = app.listen(8008, function() {
	var port = server.address().port;
	console.log(__dirname);
	console.log("Template started at port: " +port);
});