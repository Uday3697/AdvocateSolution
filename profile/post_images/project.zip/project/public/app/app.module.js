angular.module('Remedy', [
    'inProgress'
]);
