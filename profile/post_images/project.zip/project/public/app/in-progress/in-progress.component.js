function inProgressController($scope) {
    $scope.phones = [
        { number: 8658555813 },
        { number: 8895105481 },
        { number: 7504826552 }
    ];
}

angular.module('inProgress').component('inProgress', {
    templateUrl: "app/in-progress/in-progress.template.html",
    controller: inProgressController

});


